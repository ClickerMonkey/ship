package chapter2.sorting;

public class SortInsertion extends Sort
{

	@Override
	protected void doSort()
	{
		int insert;
		for (int i = 1; i < data.length; i++)
		{
			insert = data[i];
			int moveItem = i;
			while (greater(moveItem, 0) && greater(data[moveItem - 1], insert))
			{
				data[moveItem] = data[moveItem - 1];
				moveItem--;
				addSwap();
			}
			data[moveItem] = insert;
		}
	}

}
