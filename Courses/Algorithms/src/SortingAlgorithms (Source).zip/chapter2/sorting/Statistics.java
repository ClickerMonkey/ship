package chapter2.sorting;


public class Statistics 
{

	public static void main(String[] args)
	{		
		Dataset.startDataSet();
		
		Statistics s = new Statistics();
		
		s.setDatasizes(50, 75, 100, 125, 150, 200, 250, 500);
		s.setMethods(GenerateMethod.Random, GenerateMethod.Sorted, GenerateMethod.Reverse);
		s.setSorters(new SortBubble(), new SortSelection(), new SortInsertion(), new SortHeap(), new SortMerge(), new SortQuick());
		s.setRunsPerGeneration(10);
		
		s.startRuns();
	}
	
	
	private Generator generator;
	private int runsPerGeneration;
	
	private int[] sizes;
	private Sort[] sorters;
	private GenerateMethod[] methods;
	
	
	public Statistics()
	{
		generator = new Generator();
	}
	
	public void setDatasizes(int ... sizes)
	{
		this.sizes = sizes;
	}
	
	public void setSorters(Sort ... sorters)
	{
		this.sorters = sorters;
	}
	
	public void setMethods(GenerateMethod ... methods)
	{
		this.methods = methods;
	}
	
	public void setRunsPerGeneration(int runs)
	{
		runsPerGeneration = runs;
	}
	
	public void startRuns()
	{
		if (runsPerGeneration == 0 ||
			sizes == null ||
			sorters == null ||
			methods == null)
			return;
		
		for (int i = 0; i < sorters.length; i++)
			for (int j = 0; j < methods.length; j++)
				for (int k = 0; k < sizes.length; k++)
					testSort(sorters[i], methods[j], sizes[k]);
		
	}
	
	private void testSort(Sort sort, GenerateMethod method, int size)
	{
		// Keep track of the total duration in nanoseconds
		long totalDuration = 0, totalSwaps = 0, totalComparisons = 0;
		long lowDuration = Long.MAX_VALUE, lowSwaps = Long.MAX_VALUE, lowComparisons = Long.MAX_VALUE;
		long highDuration = 0, highSwaps = 0, highComparisons = 0;
		
		for (int run = 0; run < runsPerGeneration; run++)
		{
			// Do some garbage collection from previous runs.
			cleanup();
			// Generate the array based on its size and the method used.
			generator.generate(size, method);
			// Sort the array with the current sorter
			sort.sort(generator.getData());
			
			// Tally up all the execution data
			totalDuration += sort.getDuration();
			lowDuration = Math.min(lowDuration, sort.getDuration());
			highDuration = Math.max(highDuration, sort.getDuration());
			
			totalSwaps += sort.getSwaps();
			lowSwaps = Math.min(lowSwaps, sort.getSwaps());
			highSwaps = Math.max(highSwaps, sort.getSwaps());
			
			totalComparisons += sort.getComparisons();
			lowComparisons = Math.min(lowComparisons, sort.getComparisons());
			highComparisons = Math.max(highComparisons, sort.getComparisons());
		}
		
		// Find the averages for all the test ran in nanoseconds
		long avgDuration = (long)((double)totalDuration / (double)runsPerGeneration);
		long avgSwaps = (long)((double)totalSwaps / (double)runsPerGeneration);
		long avgComparisons = (long)((double)totalComparisons / (double)runsPerGeneration);
		
		Dataset.saveData(sort, method, runsPerGeneration, size, avgDuration, highDuration, lowDuration, avgSwaps, highSwaps, lowSwaps, avgComparisons, highComparisons, lowComparisons);
	}
	
	private void cleanup()
	{
		System.gc();
	}
	
}
