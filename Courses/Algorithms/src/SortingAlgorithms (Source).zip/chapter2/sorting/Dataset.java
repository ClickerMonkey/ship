package chapter2.sorting;


public class Dataset 
{

	private static String FORMAT = 
		"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n";
//	" %-13s %-8s %-7s %-7s %-12s %-12s %-12s %-12s %-12s %-12s %-12s %-12s %-12s\n";
	
	private static String[] HEADING_TOP = 
	{ "Sorting", "Array", "Total", "Data", "Duration", "Duration", "Duration", "Swap", "Swap", "Swap", "Comparison", "Comparison", "Comparison" };
	
	private static String[] HEADING_BOTTOM = 
	{ "Method", "Type", "Runs", "Size", "Avg. (ns)", "High (ns)", "Low (ns)", "Avg.", "High", "Low", "Avg.", "High", "Low" };
	
	private static String lastMethod = "";
	private static String lastType = "";
	private static int lastRuns = 0;
	
	public static void startDataSet()
	{
		System.out.format(FORMAT, (Object[])HEADING_TOP);
		System.out.format(FORMAT, (Object[])HEADING_BOTTOM);
		System.out.println();
	}
	
	public static void saveData(Sort sort, GenerateMethod method, 
			int runs, int dataSize,
			long avgDuration, long highDuration, long lowDuration, 
			long avgSwaps, long highSwaps, long lowSwaps,
			long avgComparisons, long highComparisons, long lowComparisons)
	{
		String name = sort.getClass().getSimpleName();
		String meth = method.toString();
		
		System.out.format(FORMAT, 
				(name.equals(lastMethod) ? "" : (lastMethod = name)),
				(meth.equals(lastType) ? "" : (lastType = meth)),
				(runs == lastRuns ? "" : (lastRuns = runs)),
				dataSize,
				avgDuration, highDuration, lowDuration,
				avgSwaps, highSwaps, lowSwaps,
				avgComparisons, highComparisons, lowComparisons);
	}
	
}
