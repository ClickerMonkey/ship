package chapter2.sorting;

public class SortHeap extends Sort
{

	@Override
	protected void doSort()
	{
		buildHeap();
		int n = data.length;
		
		while (n > 1)
		{
			n--;
			swap(0, n);
			downheap(0, n);
		}
	}
	
	private void buildHeap()
	{
		int start = (data.length >> 1) - 1;
		for (int v = start; v >= 0; v--)
			downheap(v, data.length);
	}
	
	private void downheap(int v, int n)
	{
		int w = (v << 1) + 1;
		while (w < n)
		{
			if (w + 1 < n && greater(data[w + 1], data[w]))
				w++;
			
			if (greaterOrEqual(data[v], data[w]))
				return;
			
			swap(v, w);
			w = ((v = w) << 1) + 1;
		}
	}

}
