package chapter2.sorting;

public abstract class Sort
{
	
	private long swaps;
	private long comparisons;
	private long duration;
	private int temp;
	
	protected int[] data;
	
	public void sort(int[] array)
	{
		data = array;
		swaps = 0;
		comparisons = 0;
		
		long startTime = System.nanoTime();
		
		doSort();
		
		duration = (System.nanoTime() - startTime);
	}
	
	protected abstract void doSort();
	
	protected final void swap(int i, int j)
	{
		temp = data[i];
		data[i] = data[j];
		data[j] = temp;
		swaps++;
	}
	
	protected final boolean less(int a, int b)
	{
		comparisons++;
		return (a < b);
	}
	
	protected final boolean lessOrEqual(int a, int b)
	{
		comparisons++;
		return (a <= b);
	}
	
	protected final boolean greater(int a, int b)
	{
		comparisons++;
		return (a > b);
	}
	
	protected final boolean greaterOrEqual(int a, int b)
	{
		comparisons++;
		return (a >= b);
	}
	
	protected final boolean equal(int a, int b)
	{
		comparisons++;
		return (a == b);
	}
	
	protected void addSwap()
	{
		swaps++;
	}
	
	protected void addComparison()
	{
		comparisons++;
	}
	
	public long getDuration()
	{
		return duration;
	}
	
	public int[] getArray()
	{
		return data;
	}
	
	public long getSwaps()
	{
		return swaps;
	}
	
	public long getComparisons()
	{
		return comparisons;
	}
	
}
