package chapter2.sorting;

public class Generator
{

	private int[] data;
	
	public Generator()
	{
		
	}
	
	public void generate(int elements, GenerateMethod method)
	{
		data = new int[elements];
		
		for (int i = 0; i < elements; i++)
			data[i] = i;
		
		// If its random shuffle around the values
		if (method == GenerateMethod.Random)
		{
			for (int i = 0; i < elements; i++)
			{
				swap(i, i + (int)(Math.random() * (elements - i)));
			}
		}
		// If its reverse then just reverse the order.
		else if (method == GenerateMethod.Reverse)
		{
			for (int i = 0; i < elements; i++)
			{
				data[i] = data[elements - i - 1];
			}
		}
	}
	
	private void swap(int i, int j)
	{
		int temp = data[i];
		data[i] = data[j];
		data[j] = temp;
	}
	
	public int[] getData()
	{
		return data;
	}
	
}
