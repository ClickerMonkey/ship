package chapter2.sorting;

public enum GenerateMethod
{
	Random,
	Sorted,
	Reverse
}
